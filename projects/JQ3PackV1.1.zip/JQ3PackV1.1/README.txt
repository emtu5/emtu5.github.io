How to install:
1. Back up your game files in case you want to revert to vanilla.
2. Move the two folders provided into the game folder.
3. Open the game and enjoy!

Difficulty: hopefully more stable with this update. This pack is NOT FOR BEGINNERS. (twisty boards, small timers etc.)

Hidden quests for Europe and South America are only possible on Orkney Islands and Anahi, respectively.

One of the levels in Hawaii has been intentionally made impossible, as there is a bug that bricks your save file if you complete the entire region.
